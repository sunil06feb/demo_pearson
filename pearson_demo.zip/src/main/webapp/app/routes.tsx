import React from 'react';
import { Switch } from 'react-router-dom';
import Loadable from 'react-loadable';
import ErrorBoundaryRoute from 'app/shared/error/error-boundary-route';
import ListComponent from './modules/list/list';
import DetailComponent from './modules/list/detail';
const Admin = Loadable({
  loader: () => import(/* webpackChunkName: "administration" */ 'app/modules/administration'),
  loading: () => <div>loading ...</div>,
});

const Routes = () => {
  return (
    <div className="view-routes">
      <Switch>
        {/* <ErrorBoundaryRoute path="/logout" component={Logout} /> */}
        {/* <PrivateRoute path="/admin" component={Admin} hasAnyAuthorities={[AUTHORITIES.ADMIN]} /> */}
        <ErrorBoundaryRoute path="/" exact component={ListComponent} />
        <ErrorBoundaryRoute path="/:id" component={DetailComponent} />
        {/* <ErrorBoundaryRoute path="/oauth2/authorization/oidc" component={LoginRedirect} /> */}
        {/* <PrivateRoute path="/" component={Entities} hasAnyAuthorities={[AUTHORITIES.USER]} /> */}
        {/* <ErrorBoundaryRoute component={PageNotFound} /> */}
      </Switch>
    </div>
  );
};

export default Routes;
