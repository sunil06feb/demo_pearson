import React, { useEffect, useRef, useState } from 'react';
import { connect } from 'react-redux';
import { NavLink as Link, useHistory } from 'react-router-dom';
import { getList } from 'app/shared/reducers/movie-list';
import { IRootState } from 'app/shared/reducers';

export const ListComponent = (props) => {
    const [alert, setAlert] = useState(false);
    const [data, setData] = useState([]);
    const [modal, setModal] = useState(false);
    const history = useHistory();
    const mounted = useRef(true);



    useEffect(() => {
        mounted.current = true;
        if (data.length && !alert) {
            return;
        }
        props.getList().then(items => {
            if (mounted.current) {
                setData(items.action.payload.data)
            }
            mounted.current = false;
        })
    }, [alert, data]);

    useEffect(() => {
        if (alert) {
            setTimeout(() => {
                setAlert(false);
            }, 1000)
        }
    }, [alert]);

    const listItems = data.map((list, index) =>
        <div className="col-4" key={index}>
            <img src={list.image_link} />
            <p>Price: {list.price}</p>
            <p>{list.brand}</p>
            <Link to={ "/" + list.id }>Details</Link>
        </div>
    );

    return (
        <>
            <div className="row">
                {listItems}
            </div>
        </>
    );
};

const mapStateToProps = (storeState: IRootState) => ({
    listItem: storeState.movieList.listItem

});

const mapDispatchToProps = { getList };

export default connect(mapStateToProps, mapDispatchToProps)(ListComponent);
