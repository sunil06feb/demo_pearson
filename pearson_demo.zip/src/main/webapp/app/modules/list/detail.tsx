import React, { useEffect, useRef, useState } from 'react';
import { useParams } from "react-router-dom";
import { getList } from 'app/shared/reducers/movie-list';
import { IRootState } from 'app/shared/reducers';
import { connect } from 'react-redux';

const DetailComponent = (props) => {

  const [alert, setAlert] = useState(false);
  const [data, setData] = useState([]);
  const mounted = useRef(true);
  const params: any = useParams();

  useEffect(() => {
    if (data.length && !alert) {
      return;
    }
    props.getList().then(item => {
      if (mounted.current) {
        const filteredItem = item.value.data.filter((desc) => Number(desc.id) === Number(params.id))
        setData(filteredItem)
      }
      mounted.current = false;
    })
  }, [alert, data]);

  useEffect(() => {
    if (alert) {
      setTimeout(() => {
        setAlert(false);
      }, 1000)
    }
  }, [alert]);

  const listItems = data.map((list, index) =>
    <div className="col-12 text-center" key={index}>
      <img src={list.image_link} />
      <div className="col-12">{list.product_colors.map((col, i) => <p key={i} style={{ backgroundColor: col.hex_value, width: '20px', height: '20px' }}></p>)}</div>
      <p>Price: {list.price}</p>
      <p>{list.brand}</p>
      <p>{list.description}</p>      
    </div>
  );

  return (
    <>
      <div className="row">
        {listItems}
      </div>
    </>
  );
};

const mapStateToProps = (storeState: IRootState) => ({
  listItem: storeState.movieList.listItem

});

const mapDispatchToProps = { getList };

export default connect(mapStateToProps, mapDispatchToProps)(DetailComponent);

