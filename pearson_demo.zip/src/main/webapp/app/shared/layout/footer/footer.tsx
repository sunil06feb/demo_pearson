import './footer.scss';

import React from 'react';
import { Translate } from 'react-jhipster';
import { Col, Row } from 'reactstrap';

const Footer = (props) => {
  return (
  <div className="footer page-content">
    <div className="container">
      <div className="row">
        <div className="col">
        </div>
      </div>
    </div>
  </div>
  )
  };

export default Footer;
