import axios from 'axios';

import { SUCCESS } from 'app/shared/reducers/action-type.util';
import { config } from 'app/config/constants';


export const ACTION_TYPES = {
  GET_LIST: 'movieList/GET_LIST',
};

const initialState = {
  listItem: [1],
};

export type MovieListState = Readonly<typeof initialState>;

export default (state: MovieListState = initialState, action): MovieListState => {
  switch (action.type) {
    case SUCCESS(ACTION_TYPES.GET_LIST): {
      const data = action.payload;

      return {
        ...state,
        listItem: data.data
      };
    }
    default:
      return state;
  }
};

const apiUrl = config.APIUrl;

export const getList = () => {
  return {
  type: ACTION_TYPES.GET_LIST,
  payload: axios.get(apiUrl)
}};
