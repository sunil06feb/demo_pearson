import { combineReducers } from 'redux';
import { loadingBarReducer as loadingBar } from 'react-redux-loading-bar';

import locale, { LocaleState } from './locale';
import authentication, { AuthenticationState } from './authentication';
import applicationProfile, { ApplicationProfileState } from './application-profile';

import administration, { AdministrationState } from 'app/modules/administration/administration.reducer';
import userManagement, { UserManagementState } from './user-management';
import movieList, { MovieListState } from './movie-list';
/* jhipster-needle-add-reducer-import - Demo will add reducer here */

export interface IRootState {
  readonly authentication: AuthenticationState;
  readonly locale: LocaleState;
  readonly applicationProfile: ApplicationProfileState;
  readonly administration: AdministrationState;
  readonly userManagement: UserManagementState;
  /* jhipster-needle-add-reducer-type - Demo will add reducer type here */
  readonly loadingBar: any;
  readonly movieList: MovieListState;
}

const rootReducer = combineReducers<IRootState>({
  authentication,
  locale,
  applicationProfile,
  administration,
  userManagement,
  /* jhipster-needle-add-reducer-combine - Demo will add reducer here */
  loadingBar,
  movieList
});

export default rootReducer;
